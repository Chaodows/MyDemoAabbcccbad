package com.example.demoaabcccbbad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

//@SpringBootApplication
public class DemoAabcccbbadApplication {

    public static void main(String[] args) {
        DemoUtil.delete("aabcccbbad");
        DemoUtil.replace("abcccbad");
    }




}
